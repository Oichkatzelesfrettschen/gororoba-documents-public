import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter
from gwpy.timeseries import TimeSeries
from gwpy.segments import Segment

matplotlib.rcParams['text.usetex'] = True
matplotlib.rcParams['axes.labelsize'] = 12
matplotlib.rcParams['legend.fontsize'] = 8
matplotlib.rcParams['xtick.labelsize'] = 8
matplotlib.rcParams['ytick.labelsize'] = 8
matplotlib.rcParams['font.size'] = 8
matplotlib.rcParams['savefig.dpi'] = 300
matplotlib.rcParams['text.latex.preamble'] = [r'\usepackage{amsmath}',r'\mathchardef\mhyphen="2D']
matplotlib.rcParams['legend.fontsize'] = 8



glitches = {'Koi_fish':[1244109006.144,(-0.25,0.25), r"$\mathrm{Koi \ Fish}$"] ,
                'Tomte':[1244181450.277,(-0.5,0.5), r"$\mathrm{Tomte}$"],
                'Slow_Scattering':[1262843671.938,(-1,1), r"$\mathrm{Slow \ scattering}$"],
                'Extremely_Loud':[1262187647.567, (-1,1), r"$\mathrm{Extremely \ Loud}$"]}

data_ = TimeSeries.DictClass()
for i in glitches:
    print("Getting data for {0}".format(i))
    t = TimeSeries.get('H1:DCS-CALIB_STRAIN_CLEAN_C01', glitches[i][0]-30, glitches[i][0] + 30,
                            frametype = 'H1_HOFT_C01').astype('float64')
    t.times = t.times.value - glitches[i][0]
    data_[i] = t.q_transform(qrange=(4,64),frange = (10,2048), outseg=Segment(glitches[i][1][0],glitches[i][1][1]),
                               tres=0.001, fres = 0.05, whiten = True)
    
plot, axes = plt.subplots(2,2,sharey=True, figsize=(8,6))
for i, ax in zip(glitches,axes.flatten()):
    pcm = ax.imshow(data_[i],vmin=0,vmax=25)
    ax.set_xlim(glitches[i][1][0],glitches[i][1][1])
    ax.set_ylim(10,1024)
    ax.set_ylabel('')
    ax.set_yscale('log')
    ax.grid(alpha=0.3)
    ax.xaxis.set_major_formatter(FormatStrFormatter(r'$%.1f$'))
    ax.plot([-100], label=glitches[i][2], visible=False)
    ax.legend(loc='upper left', handlelength=0, handletextpad=0)


plot.text(0.45, 0.02, r"$\mathrm{Time \ [seconds]}$",
          va='center', ha='center', size=12)
plot.text(0.05, 0.53, r"$\mathrm{Frequency \ [Hz]}$",
          va='center', ha='center', rotation='vertical', size=12)

cax,kw = matplotlib.colorbar.make_axes([ax for ax in axes.flat])
plt.colorbar(pcm, cax=cax,label=r"$\mathrm{Normalized \ energy}$")
plt.savefig('../figures/combined_glitches.pdf', bbox_inches='tight')