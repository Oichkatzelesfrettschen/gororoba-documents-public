## Instructions to Upload to arXiv

Note: the `minted` package causes errors because something about escapes.


> Compile with `\usepackage[finalizecache,cachedir=.]{minted}`
> go to logs and output files > other logs and files and download everything with pyg
> Place it all in the base directory
> change finalizecache to frozencache 

> Create file: `minted.sty`
> Copy the contents of https://raw.githubusercontent.com/gpoore/minted/master/source/minted.sty into it

> upload the tex+all those pyg files to arXiv